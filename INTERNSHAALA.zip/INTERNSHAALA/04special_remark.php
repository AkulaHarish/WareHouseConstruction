
<?php
	header("Location:05End.html");
	$servername = "localhost";
	$username = "root";
	$password = "";
	$con = new mysqli($servername, $username, $password);
	mysqli_select_db($con,"internshala");
	$insert_query = "INSERT INTO 04specialremarks VALUES ('".$_POST["ywc"]."','".$_POST["ywc1"]."','".$_POST["ywc2"]."')";
	mysqli_query($con,$insert_query) or die(mysqli_error($con));
	mysqli_close($con);
?>