<?php
	header("Location:02Construction_Details.html");
	$servername = "localhost";
	$username = "root";
	$password = "";
	$con = new mysqli($servername, $username, $password);
	mysqli_select_db($con,"internshala");
	$insert_query = "INSERT INTO id VALUES ('".$_POST["fname"]."','".$_POST["lname"]."','".$_POST["ph_no"]."','".$_POST["email"]."','".$_POST["warehouse_type"]."','".$_POST["city"]."','".$_POST["location"]."','".$_POST["address"]."')";
	mysqli_query($con,$insert_query) or die(mysqli_error($con));
	mysqli_close($con);
?>