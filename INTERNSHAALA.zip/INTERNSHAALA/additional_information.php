<?php
	header("Location:04special_remark.html");
	$servername = "localhost";
	$username = "root";
	$password = "";
	$con = new mysqli($servername, $username, $password);
	mysqli_select_db($con,"internshala");
	$insert_query = "INSERT INTO 03additional_information VALUES ('".$_POST["YWC"]."','".$_POST["option1"]."','".$_POST["option2"]."','".$_POST["option3"]."','".$_POST["option4"]."','".$_POST["option5"]."','".$_POST["option6"]."','".$_POST["u_platform"]."')";
	mysqli_query($con,$insert_query) or die(mysqli_error($con));
	mysqli_close($con);
?>