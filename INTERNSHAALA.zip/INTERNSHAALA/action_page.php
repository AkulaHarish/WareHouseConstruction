<?php
	header("Location:03Additional Details.html");
	$servername = "localhost";
	$username = "root";
	$password = "";
	$con = new mysqli($servername, $username, $password);
	mysqli_select_db($con,"internshala");
	$insert_query = "INSERT INTO 02constructiondetails VALUES ('".$_POST["cars"]."','".$_POST["total_plot"]."','".$_POST["car"]."','".$_POST["buildup_area"]."','".$_POST["free_space"]."','".$_POST["P_height"]."','".$_POST["Option_"]."','".$_POST["construction"]."')";
	mysqli_query($con,$insert_query) or die(mysqli_error($con));
	mysqli_close($con);
?>